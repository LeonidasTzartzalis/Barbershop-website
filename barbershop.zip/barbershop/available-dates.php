<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "barbershop";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Σφάλμα σύνδεσης: " . $conn->connect_error);
}

// Όρισε τις ώρες 
$all_times = [];
for ($h = 8; $h < 17.5; $h += 0.5) {
    $hour = floor($h);
    $minutes = ($h - $hour) == 0.5 ? "30" : "00";
    $all_times[] = sprintf("%02d:%s", $hour, $minutes);
}

// Φέρε όλα τα ραντεβού
$sql = "SELECT date, COUNT(*) AS count FROM appointments GROUP BY date";
$result = $conn->query($sql);

// Ανάλογα με τις κρατήσεις, φτιάξε τις διαθέσιμες μέρες
$availableDates = [];

$today = date('Y-m-d');
$daysToCheck = 30; // για επόμενες 30 ημέρες

for ($i = 0; $i < $daysToCheck; $i++) {
    $date = date('Y-m-d', strtotime("+$i days"));

    $sql = "SELECT COUNT(*) as cnt FROM appointments WHERE date = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $date);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    $booked = (int)$res['cnt'];

    if ($booked < count($all_times)) {
        $availableDates[] = $date;
    }
}

header('Content-Type: application/json');
echo json_encode($availableDates);
