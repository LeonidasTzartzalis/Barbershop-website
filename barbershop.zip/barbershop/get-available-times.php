<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "barbershop";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Σφάλμα σύνδεσης: " . $conn->connect_error);
}

$date = $_GET['date'];
$barber = $_GET['barber'];

// Όλες οι πιθανές ώρες
$all_times = [];
for ($h = 8; $h < 17.5; $h += 0.5) {
    $hour = floor($h);
    $minutes = ($h - $hour) == 0.5 ? "30" : "00";
    $all_times[] = sprintf("%02d:%s", $hour, $minutes);
}

// Βρες τις κρατημένες ώρες
$sql = "SELECT time FROM appointments WHERE date = ? AND barber = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $date, $barber);
$stmt->execute();
$result = $stmt->get_result();

$booked = [];
while ($row = $result->fetch_assoc()) {
  // Κρατά μόνο τις πρώτες 5 χαρακτήρες, δηλαδή "HH:MM"
  $booked[] = substr($row['time'], 0, 5);
}

// διαθέσιμες ωρες 
$available = array_values(array_diff($all_times, $booked));

header('Content-Type: application/json');
echo json_encode($available);
?>
