<?php
// PHPMailer dependencies
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// DB συνδεση
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "barbershop";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die(" Σφάλμα σύνδεσης: " . $conn->connect_error);
}

// Receive form data
$name = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$phone = $_POST['phone'] ?? '';
$date = $_POST['date'] ?? '';
$time = $_POST['time'] ?? '';
$barber = $_POST['barber'] ?? '';
$service = $_POST['service'] ?? '';

// --- δες αν υπαρχει ραντεβου στην υπαρχουσα ωρα---
$sql_check = "SELECT * FROM appointments 
              WHERE date = ? AND time = ? AND barber = ?";
$stmt = $conn->prepare($sql_check);
$stmt->bind_param("sss", $date, $time, $barber);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo " Αυτό το ραντεβού είναι ήδη κλεισμένο για τον/την $barber. Δοκιμάστε άλλη ώρα ή κουρέα.";
    exit;
}

// --- βαλε ραντεβου ---
$sql_insert = "INSERT INTO appointments (name, email, phone, date, time, barber, service)
               VALUES (?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql_insert);
$stmt->bind_param("sssssss", $name, $email, $phone, $date, $time, $barber, $service);

if ($stmt->execute()) {
    echo " Το ραντεβού καταχωρήθηκε επιτυχώς!<br>";

    // --- Send confirmation email ---
    $mail = new PHPMailer(true);
    try {
        // SMTP settings (δοκιμαστικά - ρύθμισέ τα ανάλογα με Gmail) εδω εβαλα δικα μου για τωρα
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com'; // π.χ. smtp.gmail.com
        $mail->SMTPAuth   = true;
        $mail->Username   = 'leonidastzar@gmail.com';  // email σου
        $mail->Password   = 'cjnp wgam brwy ahza';     // κωδικός σου
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        
        $mail->setFrom('you@example.com', 'Barbershop');
        $mail->addAddress($email, $name);

        // τι θα λεει το email
        $mail->isHTML(true);
        $mail->Subject = 'Επιβεβαίωση Ραντεβού';
        $mail->Body    = "
            <h2>Καλησπέρα $name,</h2>
            <p>Το ραντεβού σας επιβεβαιώθηκε:</p>
            <ul>
                <li><strong>Ημερομηνία:</strong> $date</li>
                <li><strong>Ώρα:</strong> $time</li>
                <li><strong>Υπηρεσία:</strong> $service</li>
                <li><strong>Κουρέας:</strong> $barber</li>
            </ul>
            <p>Ευχαριστούμε που μας επιλέξατε!</p>
        ";
        $mail->SMTPOptions = [
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            ]
        ];
        $mail->CharSet = 'UTF-8';
        $mail->Encoding = 'base64';
        
        $mail->send();
        echo "Στάλθηκε επιβεβαίωση στο email: $email";
    } catch (Exception $e) {
        echo " Το email δεν στάλθηκε. Σφάλμα: {$mail->ErrorInfo}";
    }

    echo "<br><br><a href='index.html'>Νέο Ραντεβού</a> | <a href='view.php'>Δες όλα τα ραντεβού</a>";
} else {
    echo "Σφάλμα καταχώρησης: " . $conn->error;
}

$conn->close();
