<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "barbershop";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Σφάλμα σύνδεσης: " . $conn->connect_error);
}

$sql = "SELECT * FROM appointments ORDER BY date, time";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="el">

<head>
    <meta charset="UTF-8">
    <title>Ραντεβού Πελατών</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <h1>Όλα τα ραντεβού</h1>
    <a href="index.html">Νέο Ραντεβού</a><br><br>
    <table border="1" cellpadding="10">
        <tr>
            <th>Όνομα</th>
            <th>Ημερομηνία</th>
            <th>Ώρα</th>
            <th>Υπηρεσία</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= htmlspecialchars($row['name']) ?></td>
                <td><?= $row['date'] ?></td>
                <td><?= $row['time'] ?></td>
                <td><?= $row['service'] ?></td>
            </tr>
        <?php endwhile; ?>
    </table>
</body>

</html>

<?php
$conn->close();
?>